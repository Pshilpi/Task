import 'dart:html';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';

void main() {
  runApp(MaterialApp(
    home:Scaffold(
      appBar: AppBar(
        title:Text('Flutter app',
        style: TextStyle(
          fontSize: 30.0,
          fontWeight: FontWeight.bold,
          letterSpacing: 2.0,
        ),
        ),
        centerTitle: true,
        backgroundColor: Colors.orange,
      ),
      body: Column (
        children: <Widget>[
          Image( image: AssetImage('assets/client-login2.jpg'),),
          Container (
            padding: EdgeInsets.only(top: 30.0,left: 5.0),
          child:   Text(
            'Email id: ',
            style: TextStyle(
              fontSize: 30.0,
              fontWeight: FontWeight.normal,
              color: Colors.indigoAccent,
            ),
          ),
          ),
          new TextField(
              decoration: new InputDecoration(
                  hintText: "Enter email id"
              )
          ),


          Container (
            padding: EdgeInsets.only(top: 40.0,left: 10.0),
            child:   Text(
              'Password: ',
              style: TextStyle(
                fontSize: 30.0,
                fontWeight: FontWeight.normal,
                color: Colors.indigoAccent,
              ),
            ),
          ),
          new TextField(
              decoration: new InputDecoration(
                  hintText: "Enter Password"
              )
          ),

        ],

  ),

  floatingActionButton: FloatingActionButton.large(
  onPressed: () {
  // Add your onPressed code here!
  },
      child:Text('Submit',
        style: TextStyle(
          fontSize: 25.0,
          fontWeight: FontWeight.normal,
        ),
      ),
  backgroundColor: Colors.green,
  ),
    ),
  ));
}
